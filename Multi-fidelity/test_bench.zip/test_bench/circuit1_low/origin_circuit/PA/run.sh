#!/bin/bash
rm -f err ocean.log sim.out
ocean -nographE -replay ./oceanScript.ocn -log ocean.log > err 2>&1
