#!/bin/bash
rm -vf oceanScript.ocn part2 ocean.log err sim.out ocean.log.cdslck
