#!/bin/bash
rm -rvf bak log tmp out err.log part2
rm -rvf opt.log opt.spec out.log record run.log tmp.spec conf
rm -rvf param result.po
